#pragma once

namespace messages
{
    namespace transmission
    {
        enum {
            PERIODIC = 4
        };
    }

    namespace reception
    {
        enum {
            STEER = 9
        };
    }
}